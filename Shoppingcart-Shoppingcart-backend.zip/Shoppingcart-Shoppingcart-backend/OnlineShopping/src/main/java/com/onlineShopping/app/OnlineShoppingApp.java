package com.onlineShopping.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineShoppingApp
{
    public static void main( String[] args )
    {
    	SpringApplication.run(OnlineShoppingApp.class, args);
		
    }
}
