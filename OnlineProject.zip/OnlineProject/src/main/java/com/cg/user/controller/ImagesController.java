
package com.cg.user.controller;

import java.sql.SQLException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.user.domain.ImagesDomain;
import com.cg.user.service.ImagesServiceInterface;

@RestController
@RequestMapping(value = "/images")
public class ImagesController {

	@Autowired
	ImagesServiceInterface imagesService;

	@GetMapping(value = "database")
	public ResponseEntity<byte[]> fromDatabaseAsResEntity(@RequestParam("id") Integer id) throws SQLException {

		Optional<ImagesDomain> images = imagesService.findById(id);
		byte[] imageBytes = null;
		if (images.isPresent()) {

			imageBytes = images.get().getPhoto().getBytes(1, (int) images.get().getPhoto().length());
		}

		return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);
	}

	/*
	 * @GetMapping(value="getAllImages") public ResponseEntity<byte[]> getAllImages(
	 * ) throws SQLException {
	 * 
	 * List<ImagesDomain> images = imagesService.findAll();
	 * 
	 * byte[] imageBytes = null; try{
	 * 
	 * imageBytes = images.get().getPhoto().getBytes(1, (int)
	 * images.get(0).getPhoto().length());
	 * 
	 * 
	 * } catch (NullPointerException e) { System.out.println("" + e); }
	 * 
	 * return
	 * ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes); }
	 */

}
